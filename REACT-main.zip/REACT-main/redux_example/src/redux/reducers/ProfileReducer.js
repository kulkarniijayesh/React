export default function ProfileReducer(state = [{"avatar": "a.png", "name": "SuperMan"}], action) {
   return state;
}