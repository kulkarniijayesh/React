import { fireEvent, render } from "@testing-library/react";
import UserList from "./UserList"


it("delete a User from UserList", () => {
    // let result = render(<UserList />);
    // fireEvent.click(result.container.querySelectorAll('button')[3]);
    // console.log(result.baseElement)

    // expect(result.originalUsers.length).toBe(1);
})