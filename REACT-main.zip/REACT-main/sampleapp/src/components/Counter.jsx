import React from 'react'

export default function Counter() {
  return (
    <div>
        <h1>Fiber Example</h1>
        <span>Count 10</span>
        <button type="button">Increment</button>
    </div>
  )
}
