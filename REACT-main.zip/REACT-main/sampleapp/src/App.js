import './App.css';
import UserList from './components/UserList';
// Functional component
function App() {
  return (
    <div className="App">
      <h1>Welcome to React World!!!</h1>
      <UserList />
    </div>
  );
}

export default App;
