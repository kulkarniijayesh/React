export interface Customer {
    id: string,
    firstName: string,
    lastName: string
}