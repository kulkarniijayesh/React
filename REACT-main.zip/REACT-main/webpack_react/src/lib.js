const add = (x, y) => x + y;

export const subtract = (x, y) => x - y;

export const multiply = (x,y) => x  * y;

export default add;